package com.example.doggychat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DisplayProfile extends AppCompatActivity {
    private static int RESULT_LOAD_IMAGE = 1;
    ProfileDB db;
    FirebaseAuth mAuth;
    ImageView profilePic;
    TextView displayName;
    TextView locationName;
    TextView userBio;
    Profile user = new Profile();
    private DrawerLayout dl;
    private ActionBarDrawerToggle menuToggle;
    Context context;
    String location;
    String name;
    Utils toasty = new Utils();





    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilepage);
        db = new ProfileDB();
        mAuth = db.getDB();
        db.setContext(this);
        String isFirstTime;
        Intent intent = getIntent();
        isFirstTime = intent.getStringExtra("firstTime");
        name = intent.getStringExtra("name");
        displayName = (TextView)findViewById(R.id.profileName);
        userBio = (TextView)findViewById(R.id.userBio);
        profilePic = findViewById(R.id.profilePicture);
        locationName = findViewById(R.id.profileLocation);
        displayName.setText(name);

        //Set the navigation drawer
        dl = (DrawerLayout) findViewById(R.id.dl);
        menuToggle = new ActionBarDrawerToggle(this, dl, R.string.Open, R.string.Close);
        menuToggle.setDrawerIndicatorEnabled(true);
        dl.addDrawerListener(menuToggle);
        menuToggle.syncState();

        //Checks if the user is new or not, if its not then this goes ahead and fills in the users information
        if(isFirstTime.equals("no")){
            location = user.updateLoc(name);
            locationName.setText(location);
            displayName.setText(name);
            StorageReference picRef = FirebaseStorage.getInstance().getReference();
            StorageReference picRef2 = picRef.child(name);
            Glide.with(this).load(picRef2.child("/profile.jpeg")).into(profilePic);
            String path = "Users/" + name +"/Bio";
            DatabaseReference mRef = FirebaseDatabase.getInstance().getReference(path);
            mRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String bio = snapshot.getValue().toString();
                    userBio.setText(bio);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

        //Handle the user clicks for navigation drawer
        NavigationView nav_view = (NavigationView)findViewById(R.id.nav_view);
        nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                //Handle each case of the menu
                int id = item.getItemId();
                context = DisplayProfile.this;

                if(id == R.id.Profile){
                    Intent intent = new Intent(context, DisplayProfile.class);
                    intent.putExtra("firstTime", "no");
                    intent.putExtra("name", name);
                    context.startActivity(intent);
                }
                else if(id == R.id.findFriends){
                    Intent intent = new Intent(context, FindFriends.class);
                    startActivity(intent);
                }
                else if (id == R.id.Settings){

                }
                else if (id == R.id.Events){
                  //  Intent intent = new Intent(context, CreatedEvents.class);
                 //   startActivity(intent);
                }
                else if (id == R.id.Chat){
                    Intent intent = new Intent(context, DisplayChat.class);
                    intent.putExtra("user", name);
                    startActivity(intent);
                }
                else if (id == R.id.MapItem){
                    Intent intent = new Intent(context, Map.class);
                    startActivity(intent);
                }
                else if (id == R.id.Preferences){
                    Intent intent = new Intent(context, Preferences.class);
                    startActivity(intent);
                }


                return true;
            }
        });

        // Sets a listener on the bio section of the page that will pop out the userbio layout to get input to populate bio section
        userBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater li = LayoutInflater.from(DisplayProfile.this);
                View promptsView = li.inflate(R.layout.userbio, null, true);
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DisplayProfile.this);
                alertDialogBuilder.setView(promptsView);
                final EditText userBioET = (EditText)promptsView.findViewById(R.id.userBioField);
                alertDialogBuilder.setCancelable(true).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userBio.setText(userBioET.getText());
                        db.updateUserBio(userBioET.getText().toString(), mAuth.getCurrentUser());
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

        //Set a listener on the button to upload a picture
        FloatingActionButton uploadPicButton = (FloatingActionButton)findViewById(R.id.uploadPictureButton);
        uploadPicButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });





    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        return menuToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }



    @Override //onStart is called right after onCreate finishes, it populates the profile page fields
    protected void onStart(){
        super.onStart();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() { //Due to asynchronous nature I had to use a wait call or else it would try to populate fields before Database finishes creating user
            @Override
            public void run() { //Used a handler here to help avoid null pointer issues with the asynch nature of android
                String name = mAuth.getCurrentUser().getDisplayName();
                location = user.updateLoc(name);
                locationName.setText(location);
                displayName.setText(name);
            }
        }, 1500);
    }


    @Override //Is called when the upload picture button is clicked and gets the local file from the user to send to database
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
        if (request == RESULT_LOAD_IMAGE && result == RESULT_OK && null != intent) {
            Uri selectedImage = intent.getData();
            profilePic.setImageURI(selectedImage);
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            db.uploadPictureFromDevice(picturePath);
            cursor.close();

        }


    }


    public void setContext(Context context){
        this.context = context;
    }


}
