package com.example.doggychat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class Preferences extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private ProfileDB db;
    FirebaseUser userID;

    private int locationPref;
    private int statusPref;
    private int eventPref;
    private int eventNotifications;
    private int statusNotfications;
    private int checkInNotifications;

    Spinner locationSpinner;
    Spinner statusSpinner;
    Spinner eventSpinner;
    Switch eventToggle;
    Switch statusToggle;
    Switch checkInToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preferences);

        db = new ProfileDB();

        // Initialize Firebase Auth
        mAuth = db.getDB();

        //Returns the users ID
        userID = mAuth.getCurrentUser();

        Button backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //return to profile
                finish();
            }
        });

        locationSpinner = (Spinner) findViewById(R.id.locationSpinner);
        fillSpinner(locationSpinner);

        statusSpinner = (Spinner) findViewById(R.id.statusSpinner);
        fillSpinner(statusSpinner);

        eventSpinner = (Spinner) findViewById(R.id.eventSpinner);
        fillSpinner(eventSpinner);

        eventToggle = findViewById(R.id.eventToggle);
        statusToggle = findViewById(R.id.statusToggle);
        checkInToggle = findViewById(R.id.checkInToggle);

        setFields();
        savePreferences();

        Button saveButton = (Button)findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //return to profile
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
    }

    private void fillSpinner(Spinner spinner){
        String[] arraySpinner = new String[] { "Only Me", "My Friends", "Everyone"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(0);//change this to be the value derives from the database

        //"Only Me", "My Friends", "Everyone" = 0,1,2

    }

    //preference - i
    //return an integer value to indicate the state of the preference requested
    public int getPrivacyPreferences (int preference){
        //Preference Variable : Possible Values
        //  location : 0,1,2 ("Only Me", "My Friends", "Everyone")
        //  status : 0,1,2 ("Only Me", "My Friends", "Everyone")
        //  events : 0,1,2 ("Only Me", "My Friends", "Everyone")
        //  -1 Value indicates an error

        //integer variable that represents the value of the preference being searched for
        int indicator = -1;

        switch(preference) {
            case 0:
                indicator = locationPref;
                break;
            case 1:
                indicator = statusPref;
                break;
            case 2:
                 indicator = eventPref;
                break;
            default:
        }

        return indicator;
    }

    //return an integer value to indicate the state of the preference requested
    public int getNotificationPreferences (int preference){
        //Preference Variable : Possible Values
        //  eventNotifications : 0,1 (False, True)
        //  statusNotifications : 0,1 (False, True)
        //  checkInNotifications : 0,1 (False, True)
        //  -1 Value indicates an error

        //integer variable that represents the value of the preference being searched for
        int indicator = -1;

        switch(preference) {
            case 0:
                indicator = eventNotifications;
                break;
            case 1:
                indicator = statusNotfications;
                break;
            case 2:
                indicator = checkInNotifications;
                break;
            default:
        }

        return indicator;

    }

    //Mising: connection to database
    //grab data from fields and store in local variables
    void savePreferences(){

        //UPLOAD PREFERENCES TO DATABASE
        locationPref = locationSpinner.getSelectedItemPosition();
        statusPref = statusSpinner.getSelectedItemPosition();
        eventPref = eventSpinner.getSelectedItemPosition();

        if(eventToggle.isChecked()){
            eventNotifications = 1;
        }else{
            eventNotifications = 0;
        }

        if(statusToggle.isChecked()){
            statusNotfications = 1;
        }else{
            statusNotfications = 0;
        }

        if(checkInToggle.isChecked()){
            checkInNotifications = 1;
        }else{
            checkInNotifications = 0;
        }

        Toast.makeText(Preferences.this, locationPref + statusPref + eventPref + " : "
                        + eventNotifications + statusNotfications + checkInNotifications,
                Toast.LENGTH_SHORT).show();
    }

    //Mising: connection to database
    //update ui fields to reflect the current values of preferences
    void setFields (){

        //GET THE UPDATED VALUES FROM DATABASE BELOW




        //set the value of each spinner
        locationSpinner.setSelection(locationPref);
        statusSpinner.setSelection(statusPref);
        eventSpinner.setSelection(eventPref);

        //set the value of each toggle
        if(eventNotifications > 0){
            eventToggle.setChecked(true);
        }else
            eventToggle.setChecked(false);

        if(statusNotfications > 0){
            statusToggle.setChecked(true);
        }else
            statusToggle.setChecked(false);

        if(checkInNotifications > 0){
            checkInToggle.setChecked(true);
        }else
            checkInToggle.setChecked(false);
    }
}