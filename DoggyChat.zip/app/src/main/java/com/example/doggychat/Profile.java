package com.example.doggychat;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.File;

public class Profile extends AppCompatActivity {

    public String name;
    public String location;
    public String status;
    public String[] friendsList;
    public int activityPoints;
    private static int RESULT_LOAD_IMAGE = 1;
    private static final int PICK_IMAGE = 100;
    UserDB db;
    FirebaseAuth mAuth;
    FirebaseUser userID;
    private StorageReference mStorageRef;
    ImageView profilePic;
    TextView displayName;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilepage);
        db = new UserDB();
        mAuth = db.getDB();
        db.setContext(this);
        displayName = (TextView)findViewById(R.id.profileName);
        profilePic = findViewById(R.id.profilePicture);
        String name = mAuth.getCurrentUser().getDisplayName();
        displayName.setText(name);
        setProfilePic();

        // Initialize Firebase Auth
        mAuth = db.getDB();

        //Returns the users ID
        userID = mAuth.getCurrentUser();
        mStorageRef = FirebaseStorage.getInstance().getReference(); //For uploading pictures

     //   StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(name);
     //   Glide.with(this).load(storageReference).into(profilePic);
        FloatingActionButton uploadPicButton = (FloatingActionButton)findViewById(R.id.uploadPictureButton);
        uploadPicButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        FloatingActionButton mapViewButton = (FloatingActionButton)findViewById(R.id.mapViewButton);
        mapViewButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //go to map view
                viewMap();

            }
        });

        FloatingActionButton preferencesButton = (FloatingActionButton)findViewById(R.id.preferencesButton);
        preferencesButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //go to preferences view
                editPreferences();
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
        if (request == RESULT_LOAD_IMAGE && result == RESULT_OK && null != intent) {
            Uri selectedImage = intent.getData();
            profilePic.setImageURI(selectedImage);
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            if(db.uploadPictureFromDevice(picturePath)){
                setProfilePic();
            }
            cursor.close();
        }


    }

    public void setProfilePic(){
        FirebaseUser user = mAuth.getCurrentUser();
        String name = user.getDisplayName() + "/profile.jpeg";
        String name2;
        FirebaseStorage fbstore = FirebaseStorage.getInstance();
        StorageReference storageReference = fbstore.getReference();
        StorageReference storageReference1 = storageReference.child(name);
        Glide.with(this).load(storageReference1).into(profilePic);
        Toast.makeText(Profile.this, "The display name is(from profile class): " + name,
                Toast.LENGTH_SHORT).show();

    }

    public void createProfile(){

    }

    public void editName(){

    }

    public void editLocation(){

    }

    public void editPreferences(){
        Intent intent = new Intent(this, Preferences.class);
        startActivity(intent);
    }


    public void changePicture(String path){

        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);

        //create file object with path passed in
        Uri file = Uri.fromFile(new File(path));

        // Upload file (without metadata) to the path 'UserFiles/Photos/mountains.jpg'
        StorageTask<UploadTask.TaskSnapshot> uploadTask = mStorageRef.child("Photos/"+file.getLastPathSegment()).putFile(file);

        // Register observers to listen for when the download is done or if it fails
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle unsuccessful uploads



            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                //Change the picture in the GUI
                Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                startActivityForResult(gallery, PICK_IMAGE);



            }
        });

    }


    public void addFriend(){

    }

    public void viewMap(){
        Intent intent = new Intent(this, Map.class);
        startActivity(intent);
    }


}
