package com.example.doggychat;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DisplayChat extends AppCompatActivity {


    String message;
    public ListView msgBox;
    public EditText msg;
    public FloatingActionButton send;
    Chat chat;


    @Override
    protected void onCreate(Bundle SavedInstanceBundle){
        super.onCreate(SavedInstanceBundle);
        setContentView(R.layout.chatpage);
        msgBox = (ListView)findViewById(R.id.list_of_messages);
        msg = (EditText)findViewById(R.id.input);
        send = (FloatingActionButton)findViewById(R.id.fab);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                message = msg.getText().toString();
                chat.sendMessage(message, message);
                chat.updateHistory(message);
            }
        });




    }



}
