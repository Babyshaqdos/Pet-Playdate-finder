package com.example.doggychat;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Profile extends AppCompatActivity {

    public String name;
    public String location;
    public String status;
    public String[] friendsList;
    public int activityPoints;
    private static int RESULT_LOAD_IMAGE = 1;
    UserDB db;
    FirebaseAuth mAuth;
    ImageView profilePic;
    TextView displayName;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilepage);
        db = new UserDB();
        mAuth = db.getDB();
        db.setContext(this);
        displayName = (TextView)findViewById(R.id.profileName);
        profilePic = findViewById(R.id.profilePicture);
        String name = mAuth.getCurrentUser().getDisplayName();
        displayName.setText(name);
        setProfilePic();
     //   StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(name);
     //   Glide.with(this).load(storageReference).into(profilePic);
        FloatingActionButton uploadPicButton = (FloatingActionButton)findViewById(R.id.uploadPictureButton);
        uploadPicButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
        if (request == RESULT_LOAD_IMAGE && result == RESULT_OK && null != intent) {
            Uri selectedImage = intent.getData();
            profilePic.setImageURI(selectedImage);
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            if(db.uploadPictureFromDevice(picturePath)){
                setProfilePic();
            }
            cursor.close();
        }


    }

    public void setProfilePic(){
        FirebaseUser user = mAuth.getCurrentUser();
        String name = user.getDisplayName() + "/profile.jpeg";
        String name2;
        FirebaseStorage fbstore = FirebaseStorage.getInstance();
        StorageReference storageReference = fbstore.getReference();
        StorageReference storageReference1 = storageReference.child(name);
        Glide.with(this).load(storageReference1).into(profilePic);
        Toast.makeText(Profile.this, "The display name is(from profile class): " + name,
                Toast.LENGTH_SHORT).show();

    }

    public void createProfile(){

    }

    public void editName(){

    }

    public void editLocation(){

    }

    public void editPreferences(){

    }


    public void changePicture(){

    }


    public void addFriend(){

    }


}
