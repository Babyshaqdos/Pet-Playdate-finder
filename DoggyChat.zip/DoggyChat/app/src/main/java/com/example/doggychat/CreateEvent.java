package com.example.doggychat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.GeoPoint;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class CreateEvent extends AppCompatActivity implements
        GoogleMap.OnMyLocationButtonClickListener,
        GoogleMap.OnMyLocationClickListener,
        OnMapReadyCallback,
        ActivityCompat.OnRequestPermissionsResultCallback {

    FirebaseDatabase database;
    String displayName;


    private GoogleMap map;

    private int locationPref;
    private EditText eventNameField;
    private EditText locationField;
    private EditText timeField;
    private EditText dateField;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createeventpage);


        //setup toolbar at top of screen
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ProfileDB db = new ProfileDB();

        // Initialize Firebase Auth
        FirebaseAuth mAuth = db.getDB();

        //Returns the users display name
        displayName = mAuth.getCurrentUser().getDisplayName();

        eventNameField = (EditText)findViewById(R.id.eventNameFIeld);
        locationField = (EditText)findViewById(R.id.locationField);
        timeField = (EditText)findViewById(R.id.timeField);
        dateField = (EditText)findViewById(R.id.dateField);


        GeocodingLocation locationAddress = new GeocodingLocation();
        locationAddress.getAddressFromLocation("611 Osage Street",
                getApplicationContext(), new GeocoderHandler());

        Button postButton = (Button)findViewById(R.id.saveButton);
        postButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                postEvent();//upload preferences to database
                finish();//return to profile
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //grab data from fields and store in database
    //if data fields have not been manipulated by user, a default set of values will be set
    private void postEvent(){

        String eventName = eventNameField.getText().toString();
        String eventLocation = locationField.getText().toString();
        String eventTime = timeField.getText().toString();
        String eventDate = dateField.getText().toString();


        database = FirebaseDatabase.getInstance();
        DatabaseReference events = database.getReference().child("Events");

        String databaseEventLocation = getLocationFromAddress(eventLocation).replaceAll("\\.","_");
        if(!databaseEventLocation.equals("")){
            DatabaseReference currEvent = events.child(databaseEventLocation);
            currEvent.child("Event Name").setValue(eventName);
            currEvent.child("Time").setValue(eventTime);
            currEvent.child("Date").setValue(eventDate);
            currEvent.child("User").setValue(displayName);
        }else{
            //GEOCODER BUG -- (out of your hands, well documented problem)
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        map.setOnMyLocationButtonClickListener(this);
        map.setOnMyLocationClickListener(this);
        enableMyLocation();
        googleMap.addMarker(new MarkerOptions()
                .position(new LatLng(0, 0))
                .title(displayName));

        String address = getLocationFromAddress("611 Osage Street Normal, IL");
        if(!address.equals("")){
            String [] latLng = address.split(",");
            double latitude = Double.parseDouble(latLng[0]);
            double longitude = Double.parseDouble(latLng[1]);

            LatLng location = new LatLng(latitude, longitude);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 15));
        }
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (map != null) {
                map.setMyLocationEnabled(true);
            }
        }
    }

    private final LocationListener mLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(final Location location) {
            //your code here
        }
    };

    public String getLocationFromAddress(String strAddress){

        Geocoder coder = new Geocoder(this);
        List<Address> address;

        try {
            address = coder.getFromLocationName(strAddress,1);
            if (address==null) {
                return null;
            }
            Address location=address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latLng = location.getLatitude() + "," + location.getLongitude();
            Toast.makeText(this, latLng, Toast.LENGTH_LONG).show();

            return latLng;
        } catch (IOException e) {
            Toast.makeText(this, "Uh Oh", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        //Toast.makeText(this, "Made it here", Toast.LENGTH_LONG).show();
        return null;
    }
}

