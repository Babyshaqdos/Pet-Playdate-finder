package com.example.doggychat;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Post {

    public String uid;
    public String sender;
    public String title;
    public String message;
    public int starCount =0;
    public Map<String, Boolean> stars = new HashMap<>();

    public Post(){

    }

    public Post(String uid, String sender, String title, String body){
        this.uid = uid;
        this.sender = sender;
        this.title = title;
        this.message = body;
    }

    @Exclude
    public Map<String, Object> toMap(){
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("sender", sender);
        result.put("title", title);
        result.put("message", message);
        result.put("starCount", starCount);
        result.put("stars", stars);
        return result;
    }




}
