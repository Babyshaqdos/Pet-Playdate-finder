package com.example.doggychat;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.storage.FirebaseStorage;


public class Preferences extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preferences);

        Button backButton = (Button)findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //return to profile
                finish();
            }
        });

        Spinner locationSpinner = (Spinner) findViewById(R.id.locationSpinner);
        fillSpinner(locationSpinner);

        Spinner statusSpinner = (Spinner) findViewById(R.id.statusSpinner);
        fillSpinner(statusSpinner);

        Spinner eventSpinner = (Spinner) findViewById(R.id.eventSpinner);
        fillSpinner(eventSpinner);

        Switch eventToggle = findViewById(R.id.eventToggle);
        Switch statusToggle = findViewById(R.id.statusToggle);
        Switch checkInToggle = findViewById(R.id.checkInToggle);

        Button saveButton = (Button)findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                //return to profile
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);


    }

    private void fillSpinner(Spinner spinner){
        String[] arraySpinner = new String[] { "Everyone", "Custom Group", "Only Me"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }





}