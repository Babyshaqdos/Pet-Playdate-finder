package com.example.doggychat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

import java.util.List;

public class FriendAdapter extends RecyclerView.Adapter<FriendAdapter.ViewHolder> {

    private Context context;
    private List<String> mUsers;
    private OnNoteListener mOnNotListener;

    public FriendAdapter(Context context, List<String> mUsers, OnNoteListener mOnNotListener){
        this.context = context;
        this.mUsers = mUsers;
        this.mOnNotListener = mOnNotListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.friend_item, parent, false);
        return new FriendAdapter.ViewHolder(view, mOnNotListener);
    }

    @Override
    public void onBindViewHolder(@NonNull FriendAdapter.ViewHolder holder, int position) {
        String displayName = mUsers.get(position);
        holder.username2.setText(displayName);
        StorageReference picRef = FirebaseStorage.getInstance().getReference().child(displayName);
        if(picRef.child("/profile.jpeg") != null){
            Glide.with(context).load(picRef.child("/profile.jpeg")).into(holder.profileImage2);
        }
        else{
            holder.profileImage2.setImageResource(R.mipmap.ic_launcher);
        }
    }

    @Override
    public int getItemCount() {
        return mUsers.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        OnNoteListener onListener;
        public TextView username2;
        public ImageView profileImage2;


        public ViewHolder(View itemView, OnNoteListener mOnNotListener){
            super(itemView);
            username2 = itemView.findViewById(R.id.friendName);
            profileImage2 = itemView.findViewById(R.id.friendProfileImage);
            this.onListener = mOnNotListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onListener.onNoteClick(getAdapterPosition());
        }
    }

    public interface OnNoteListener{
        void onNoteClick(int position);
    }


}
