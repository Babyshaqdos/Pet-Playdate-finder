package com.example.doggychat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DisplayOtherProfile extends AppCompatActivity {

    //This class is the same as displayProfile only it takes different intent parameters in order to display the information for a different user
    //Other than the one that is logged in to the application




    private static int RESULT_LOAD_IMAGE = 1;
    ProfileDB db;
    FirebaseAuth mAuth;
    ImageView profilePic2;
    TextView displayName2;
    TextView locationName2;
    TextView userBio2;
    FloatingActionButton addButton;
    private DrawerLayout dl;
    private ActionBarDrawerToggle menuToggle;
    Context context;
    String location;
    String name;
    Utils toasty = new Utils();


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend_profile);

        db = new ProfileDB();
        mAuth = db.getDB();


        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        StorageReference picRef = FirebaseStorage.getInstance().getReference().child(name).child("/profile.jpeg");

        displayName2 = (TextView)findViewById(R.id.friendprofileName);
        locationName2 = (TextView)findViewById(R.id.friendprofileLocation);
        profilePic2 = (ImageView)findViewById(R.id.friendprofilePicture);
        userBio2 = (TextView)findViewById(R.id.friendBio);
        addButton = (FloatingActionButton)findViewById(R.id.addFriendButton);
        displayName2.setText(name);
        String path = "Users/" + name +"/Bio";
        String locPath = "Users/" + name +"/Location";

        //Set profile picture
        if(picRef != null){
            Glide.with(this).load(picRef).into(profilePic2);
        }

        //Get the users bio description
        DatabaseReference mRef = FirebaseDatabase.getInstance().getReference(path);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    String bio = snapshot.getValue().toString();
                    userBio2.setText(bio);
                }
                catch (Exception e){

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                }
            });

        //Get the users location
        DatabaseReference locRef = FirebaseDatabase.getInstance().getReference(locPath);
        locRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String location = snapshot.getValue().toString();
                locationName2.setText(location);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        //Add listener to add friend
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseDatabase mDB = FirebaseDatabase.getInstance();
                DatabaseReference mRef = mDB.getReference("/Users/" + mAuth.getCurrentUser().getDisplayName() +"/Friends");
                mRef.child(name).setValue(true);

            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        return menuToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }





    @Override //Is called when the upload picture button is clicked and gets the local file from the user to send to database
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
        if (request == RESULT_LOAD_IMAGE && result == RESULT_OK && null != intent) {
            Uri selectedImage = intent.getData();
            profilePic2.setImageURI(selectedImage);
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            db.uploadPictureFromDevice(picturePath);
            cursor.close();

        }


    }


    public void setContext(Context context){
        this.context = context;
    }


}


