package com.example.doggychat;

import android.widget.ListView;

import java.util.HashMap;
import java.util.Map;

public class Chat implements Mediator {

    public Map<String, String> messages = new HashMap<>();


    @Override
    public void sendMessage(String message, String recipient) {

    }

    @Override
    public void receiveMessage() {

    }

    @Override
    public void updateHistory(String message) {

    }
}
