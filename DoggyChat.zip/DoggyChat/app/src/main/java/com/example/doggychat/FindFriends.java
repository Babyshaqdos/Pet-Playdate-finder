package com.example.doggychat;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FindFriends extends AppCompatActivity implements FriendAdapter.OnNoteListener {

    private RecyclerView friendRecycler;
    private FriendAdapter friendAdapter;
    private List<String> mUser;
    Context context;
    String name;
    FirebaseAuth mAuth;
    ProfileDB db;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.findfriends);
        context = FindFriends.this;
        LayoutInflater inflater;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.friendLayout);
        View view = inflater.inflate(R.layout.findfriends, layout, true);
        friendRecycler = view.findViewById(R.id.friendsRecycler);
        friendRecycler.setHasFixedSize(true);
        friendRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        db = new ProfileDB();
        mAuth = db.getDB();
        name = mAuth.getCurrentUser().getDisplayName();
        mUser = new ArrayList<>();
        readUsers(name);


    }

    private void readUsers(String name){
        final Utils toasty = new Utils();
        final String user = name;
        DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("Users");
        toasty.showToast(context, "our mRef " + mRef.toString());
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUser.clear();
                for(DataSnapshot snap1: snapshot.getChildren()){
                    String displayName = snap1.getKey();
                    if(!mUser.contains(displayName) && displayName != user){
                      //  toasty.showToast(context, "We have a value " + displayName);
                        mUser.add(displayName);
                    }
                }
                friendAdapter = new FriendAdapter(getApplicationContext(), mUser, FindFriends.this);
                friendRecycler.setAdapter(friendAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public void onNoteClick(int position) {
        Intent intent = new Intent(context, DisplayOtherProfile.class);
        intent.putExtra("name", mUser.get(position));
        startActivity(intent);
    }
}

