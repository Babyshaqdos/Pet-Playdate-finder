package com.example.doggychat;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Profile extends AppCompatActivity {

    public String name;
    public String location;
    public String status;
    public String[] friendsList;
    public int activityPoints;
    private static int RESULT_LOAD_IMAGE = 1;
    UserDB db;
    FirebaseAuth mAuth;
    ImageView profilePic;
    TextView displayName;
    TextView locationName;
    TextView userBio;

    @Override //onCreate is the very first method called when this class is instantiated from an intent
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilepage);
        db = new UserDB();
        mAuth = db.getDB();
        db.setContext(this);
        displayName = (TextView)findViewById(R.id.profileName);
        userBio = (TextView)findViewById(R.id.userBio);
        profilePic = findViewById(R.id.profilePicture);
        locationName = findViewById(R.id.profileLocation);
        String name = mAuth.getCurrentUser().getDisplayName();
        displayName.setText(name);


        // Sets a listener on the bio section of the page that will pop out the userbio layout to get input to populate bio section
        userBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater li = LayoutInflater.from(Profile.this);
                View promptsView = li.inflate(R.layout.userbio, null, true);
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Profile.this);
                alertDialogBuilder.setView(promptsView);
                final EditText userBioET = (EditText)promptsView.findViewById(R.id.userBioField);
                alertDialogBuilder.setCancelable(true).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userBio.setText(userBioET.getText());
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

        //Set a listener on the button to upload a picture
        FloatingActionButton uploadPicButton = (FloatingActionButton)findViewById(R.id.uploadPictureButton);
        uploadPicButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
    }

    @Override //onStart is called right after onCreate finishes, it populates the profile page fields
    protected void onStart(){
        super.onStart();
        profilePic.setImageURI(mAuth.getCurrentUser().getPhotoUrl());
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() { //Due to asynchronous nature I had to use a wait call or else it would try to populate fields before Database finishes creating user
            @Override
            public void run() {
                updateLoc();
                String name = mAuth.getCurrentUser().getDisplayName();
                displayName.setText(name);
                profilePic.setImageURI(mAuth.getCurrentUser().getPhotoUrl());
            }
        }, 500);
    }

    //Adds a listener on the database so if the location changes then the profile page will be updated
    public void updateLoc(){
        DatabaseReference dbref;
        dbref = FirebaseDatabase.getInstance().getReference().child("Users");
        String name = mAuth.getCurrentUser().getDisplayName();
        dbref.child(name).child("Location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try{
                    if(snapshot.getValue() != null){
                        try{
                            locationName.setText(snapshot.getValue().toString());
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                    else{

                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



    @Override //Is called when the upload picture button is clicked and gets the local file from the user to send to database
    protected void onActivityResult(int request, int result, Intent intent){
        super.onActivityResult(request, result, intent);
        if (request == RESULT_LOAD_IMAGE && result == RESULT_OK && null != intent) {
            Uri selectedImage = intent.getData();
            profilePic.setImageURI(selectedImage);
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            db.uploadPictureFromDevice(picturePath);
            cursor.close();

        }


    }

    //Not currently in use
    public void setProfilePic(){
        FirebaseUser user = mAuth.getCurrentUser();
        String name = user.getDisplayName() + "/profile.jpeg";
        String name2;
        FirebaseStorage fbstore = FirebaseStorage.getInstance();
        StorageReference storageReference = fbstore.getReference();
        StorageReference storageReference1 = storageReference.child(name);
        Glide.with(this).load(storageReference1).into(profilePic);
        Toast.makeText(Profile.this, "The display name is(from profile class): " + name,
                Toast.LENGTH_SHORT).show();

    }

    public void createProfile(){

    }

    public void editName(){

    }

    public void editLocation(){

    }

    public void editPreferences(){

    }


    public void changePicture(){

    }


    public void addFriend(){

    }


}
